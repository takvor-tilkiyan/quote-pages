import lcddriver
import time
from datetime import datetime

class Quote:
    def __init__(self, text, author):
        self.text = text
        self.author = author

QUOTES = [Quote("Greatness is a lot of small things done well.", "Ray Lewis"),
          Quote("It will eventually pay off.", "Evanthea Spanos"),
          Quote("I've had a lot of worries in my life, most of which never happened.", "Mark Twain")]

LINE_WIDTH = 16

display = lcddriver.lcd()

try:
    while True:
        
        for q in QUOTES:
            print("Showing quote '" + q.text + "' by " + q.author + " at " + datetime.now().isoformat()) 

            q_text = " " * LINE_WIDTH + q.text.rjust(len(q.author)) + " " * LINE_WIDTH
            q_author = " " * LINE_WIDTH + q.author.rjust(len(q.text))  + " " * LINE_WIDTH
            for i in range(max(len(q_text), len(q_author)) - LINE_WIDTH):
                display.lcd_display_string(q_text[i:i+LINE_WIDTH], 1)
                display.lcd_display_string(q_author[i:i+LINE_WIDTH], 2)
                time.sleep(0.3)

except KeyboardInterrupt:
    print("Cleaning up at " + datetime.now().isoformat())
    display.lcd_clear()

